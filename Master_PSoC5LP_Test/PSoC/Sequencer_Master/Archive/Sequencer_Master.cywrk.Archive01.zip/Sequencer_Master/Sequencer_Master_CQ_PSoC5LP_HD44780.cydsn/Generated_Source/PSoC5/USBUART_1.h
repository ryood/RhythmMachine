/*******************************************************************************
* File Name: USBUART_1.h
* Version 2.50
*
* Description:
*  Contains the function prototypes and constants available to the UART
*  user module.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/


#if !defined(CY_UART_USBUART_1_H)
#define CY_UART_USBUART_1_H

#include "cytypes.h"
#include "cyfitter.h"
#include "CyLib.h"


/***************************************
* Conditional Compilation Parameters
***************************************/

#define USBUART_1_RX_ENABLED                     (1u)
#define USBUART_1_TX_ENABLED                     (1u)
#define USBUART_1_HD_ENABLED                     (0u)
#define USBUART_1_RX_INTERRUPT_ENABLED           (0u)
#define USBUART_1_TX_INTERRUPT_ENABLED           (0u)
#define USBUART_1_INTERNAL_CLOCK_USED            (1u)
#define USBUART_1_RXHW_ADDRESS_ENABLED           (0u)
#define USBUART_1_OVER_SAMPLE_COUNT              (8u)
#define USBUART_1_PARITY_TYPE                    (0u)
#define USBUART_1_PARITY_TYPE_SW                 (0u)
#define USBUART_1_BREAK_DETECT                   (0u)
#define USBUART_1_BREAK_BITS_TX                  (13u)
#define USBUART_1_BREAK_BITS_RX                  (13u)
#define USBUART_1_TXCLKGEN_DP                    (1u)
#define USBUART_1_USE23POLLING                   (1u)
#define USBUART_1_FLOW_CONTROL                   (0u)
#define USBUART_1_CLK_FREQ                       (0u)
#define USBUART_1_TX_BUFFER_SIZE                 (4u)
#define USBUART_1_RX_BUFFER_SIZE                 (4u)

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component UART_v2_50 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */

#if defined(USBUART_1_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG)
    #define USBUART_1_CONTROL_REG_REMOVED            (0u)
#else
    #define USBUART_1_CONTROL_REG_REMOVED            (1u)
#endif /* End USBUART_1_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */


/***************************************
*      Data Structure Definition
***************************************/

/* Sleep Mode API Support */
typedef struct USBUART_1_backupStruct_
{
    uint8 enableState;

    #if(USBUART_1_CONTROL_REG_REMOVED == 0u)
        uint8 cr;
    #endif /* End USBUART_1_CONTROL_REG_REMOVED */

} USBUART_1_BACKUP_STRUCT;


/***************************************
*       Function Prototypes
***************************************/

void USBUART_1_Start(void) ;
void USBUART_1_Stop(void) ;
uint8 USBUART_1_ReadControlRegister(void) ;
void USBUART_1_WriteControlRegister(uint8 control) ;

void USBUART_1_Init(void) ;
void USBUART_1_Enable(void) ;
void USBUART_1_SaveConfig(void) ;
void USBUART_1_RestoreConfig(void) ;
void USBUART_1_Sleep(void) ;
void USBUART_1_Wakeup(void) ;

/* Only if RX is enabled */
#if( (USBUART_1_RX_ENABLED) || (USBUART_1_HD_ENABLED) )

    #if (USBUART_1_RX_INTERRUPT_ENABLED)
        #define USBUART_1_EnableRxInt()  CyIntEnable (USBUART_1_RX_VECT_NUM)
        #define USBUART_1_DisableRxInt() CyIntDisable(USBUART_1_RX_VECT_NUM)
        CY_ISR_PROTO(USBUART_1_RXISR);
    #endif /* USBUART_1_RX_INTERRUPT_ENABLED */

    void USBUART_1_SetRxAddressMode(uint8 addressMode)
                                                           ;
    void USBUART_1_SetRxAddress1(uint8 address) ;
    void USBUART_1_SetRxAddress2(uint8 address) ;

    void  USBUART_1_SetRxInterruptMode(uint8 intSrc) ;
    uint8 USBUART_1_ReadRxData(void) ;
    uint8 USBUART_1_ReadRxStatus(void) ;
    uint8 USBUART_1_GetChar(void) ;
    uint16 USBUART_1_GetByte(void) ;
    uint8 USBUART_1_GetRxBufferSize(void)
                                                            ;
    void USBUART_1_ClearRxBuffer(void) ;

    /* Obsolete functions, defines for backward compatible */
    #define USBUART_1_GetRxInterruptSource   USBUART_1_ReadRxStatus

#endif /* End (USBUART_1_RX_ENABLED) || (USBUART_1_HD_ENABLED) */

/* Only if TX is enabled */
#if(USBUART_1_TX_ENABLED || USBUART_1_HD_ENABLED)

    #if(USBUART_1_TX_INTERRUPT_ENABLED)
        #define USBUART_1_EnableTxInt()  CyIntEnable (USBUART_1_TX_VECT_NUM)
        #define USBUART_1_DisableTxInt() CyIntDisable(USBUART_1_TX_VECT_NUM)
        #define USBUART_1_SetPendingTxInt() CyIntSetPending(USBUART_1_TX_VECT_NUM)
        #define USBUART_1_ClearPendingTxInt() CyIntClearPending(USBUART_1_TX_VECT_NUM)
        CY_ISR_PROTO(USBUART_1_TXISR);
    #endif /* USBUART_1_TX_INTERRUPT_ENABLED */

    void USBUART_1_SetTxInterruptMode(uint8 intSrc) ;
    void USBUART_1_WriteTxData(uint8 txDataByte) ;
    uint8 USBUART_1_ReadTxStatus(void) ;
    void USBUART_1_PutChar(uint8 txDataByte) ;
    void USBUART_1_PutString(const char8 string[]) ;
    void USBUART_1_PutArray(const uint8 string[], uint8 byteCount)
                                                            ;
    void USBUART_1_PutCRLF(uint8 txDataByte) ;
    void USBUART_1_ClearTxBuffer(void) ;
    void USBUART_1_SetTxAddressMode(uint8 addressMode) ;
    void USBUART_1_SendBreak(uint8 retMode) ;
    uint8 USBUART_1_GetTxBufferSize(void)
                                                            ;
    /* Obsolete functions, defines for backward compatible */
    #define USBUART_1_PutStringConst         USBUART_1_PutString
    #define USBUART_1_PutArrayConst          USBUART_1_PutArray
    #define USBUART_1_GetTxInterruptSource   USBUART_1_ReadTxStatus

#endif /* End USBUART_1_TX_ENABLED || USBUART_1_HD_ENABLED */

#if(USBUART_1_HD_ENABLED)
    void USBUART_1_LoadRxConfig(void) ;
    void USBUART_1_LoadTxConfig(void) ;
#endif /* End USBUART_1_HD_ENABLED */


/* Communication bootloader APIs */
#if defined(CYDEV_BOOTLOADER_IO_COMP) && ((CYDEV_BOOTLOADER_IO_COMP == CyBtldr_USBUART_1) || \
                                          (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Custom_Interface))
    /* Physical layer functions */
    void    USBUART_1_CyBtldrCommStart(void) CYSMALL ;
    void    USBUART_1_CyBtldrCommStop(void) CYSMALL ;
    void    USBUART_1_CyBtldrCommReset(void) CYSMALL ;
    cystatus USBUART_1_CyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut) CYSMALL
             ;
    cystatus USBUART_1_CyBtldrCommRead(uint8 pData[], uint16 size, uint16 * count, uint8 timeOut) CYSMALL
             ;

    #if (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_USBUART_1)
        #define CyBtldrCommStart    USBUART_1_CyBtldrCommStart
        #define CyBtldrCommStop     USBUART_1_CyBtldrCommStop
        #define CyBtldrCommReset    USBUART_1_CyBtldrCommReset
        #define CyBtldrCommWrite    USBUART_1_CyBtldrCommWrite
        #define CyBtldrCommRead     USBUART_1_CyBtldrCommRead
    #endif  /* (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_USBUART_1) */

    /* Byte to Byte time out for detecting end of block data from host */
    #define USBUART_1_BYTE2BYTE_TIME_OUT (25u)
    #define USBUART_1_PACKET_EOP         (0x17u) /* End of packet defined by bootloader */
    #define USBUART_1_WAIT_EOP_DELAY     (5u)    /* Additional 5ms to wait for End of packet */
    #define USBUART_1_BL_CHK_DELAY_MS    (1u)    /* Time Out quantity equal 1mS */

#endif /* CYDEV_BOOTLOADER_IO_COMP */


/***************************************
*          API Constants
***************************************/
/* Parameters for SetTxAddressMode API*/
#define USBUART_1_SET_SPACE      (0x00u)
#define USBUART_1_SET_MARK       (0x01u)

/* Status Register definitions */
#if( (USBUART_1_TX_ENABLED) || (USBUART_1_HD_ENABLED) )
    #if(USBUART_1_TX_INTERRUPT_ENABLED)
        #define USBUART_1_TX_VECT_NUM            (uint8)USBUART_1_TXInternalInterrupt__INTC_NUMBER
        #define USBUART_1_TX_PRIOR_NUM           (uint8)USBUART_1_TXInternalInterrupt__INTC_PRIOR_NUM
    #endif /* USBUART_1_TX_INTERRUPT_ENABLED */

    #define USBUART_1_TX_STS_COMPLETE_SHIFT          (0x00u)
    #define USBUART_1_TX_STS_FIFO_EMPTY_SHIFT        (0x01u)
    #define USBUART_1_TX_STS_FIFO_NOT_FULL_SHIFT     (0x03u)
    #if(USBUART_1_TX_ENABLED)
        #define USBUART_1_TX_STS_FIFO_FULL_SHIFT     (0x02u)
    #else /* (USBUART_1_HD_ENABLED) */
        #define USBUART_1_TX_STS_FIFO_FULL_SHIFT     (0x05u)  /* Needs MD=0 */
    #endif /* (USBUART_1_TX_ENABLED) */

    #define USBUART_1_TX_STS_COMPLETE            (uint8)(0x01u << USBUART_1_TX_STS_COMPLETE_SHIFT)
    #define USBUART_1_TX_STS_FIFO_EMPTY          (uint8)(0x01u << USBUART_1_TX_STS_FIFO_EMPTY_SHIFT)
    #define USBUART_1_TX_STS_FIFO_FULL           (uint8)(0x01u << USBUART_1_TX_STS_FIFO_FULL_SHIFT)
    #define USBUART_1_TX_STS_FIFO_NOT_FULL       (uint8)(0x01u << USBUART_1_TX_STS_FIFO_NOT_FULL_SHIFT)
#endif /* End (USBUART_1_TX_ENABLED) || (USBUART_1_HD_ENABLED)*/

#if( (USBUART_1_RX_ENABLED) || (USBUART_1_HD_ENABLED) )
    #if(USBUART_1_RX_INTERRUPT_ENABLED)
        #define USBUART_1_RX_VECT_NUM            (uint8)USBUART_1_RXInternalInterrupt__INTC_NUMBER
        #define USBUART_1_RX_PRIOR_NUM           (uint8)USBUART_1_RXInternalInterrupt__INTC_PRIOR_NUM
    #endif /* USBUART_1_RX_INTERRUPT_ENABLED */
    #define USBUART_1_RX_STS_MRKSPC_SHIFT            (0x00u)
    #define USBUART_1_RX_STS_BREAK_SHIFT             (0x01u)
    #define USBUART_1_RX_STS_PAR_ERROR_SHIFT         (0x02u)
    #define USBUART_1_RX_STS_STOP_ERROR_SHIFT        (0x03u)
    #define USBUART_1_RX_STS_OVERRUN_SHIFT           (0x04u)
    #define USBUART_1_RX_STS_FIFO_NOTEMPTY_SHIFT     (0x05u)
    #define USBUART_1_RX_STS_ADDR_MATCH_SHIFT        (0x06u)
    #define USBUART_1_RX_STS_SOFT_BUFF_OVER_SHIFT    (0x07u)

    #define USBUART_1_RX_STS_MRKSPC           (uint8)(0x01u << USBUART_1_RX_STS_MRKSPC_SHIFT)
    #define USBUART_1_RX_STS_BREAK            (uint8)(0x01u << USBUART_1_RX_STS_BREAK_SHIFT)
    #define USBUART_1_RX_STS_PAR_ERROR        (uint8)(0x01u << USBUART_1_RX_STS_PAR_ERROR_SHIFT)
    #define USBUART_1_RX_STS_STOP_ERROR       (uint8)(0x01u << USBUART_1_RX_STS_STOP_ERROR_SHIFT)
    #define USBUART_1_RX_STS_OVERRUN          (uint8)(0x01u << USBUART_1_RX_STS_OVERRUN_SHIFT)
    #define USBUART_1_RX_STS_FIFO_NOTEMPTY    (uint8)(0x01u << USBUART_1_RX_STS_FIFO_NOTEMPTY_SHIFT)
    #define USBUART_1_RX_STS_ADDR_MATCH       (uint8)(0x01u << USBUART_1_RX_STS_ADDR_MATCH_SHIFT)
    #define USBUART_1_RX_STS_SOFT_BUFF_OVER   (uint8)(0x01u << USBUART_1_RX_STS_SOFT_BUFF_OVER_SHIFT)
    #define USBUART_1_RX_HW_MASK                     (0x7Fu)
#endif /* End (USBUART_1_RX_ENABLED) || (USBUART_1_HD_ENABLED) */

/* Control Register definitions */
#define USBUART_1_CTRL_HD_SEND_SHIFT                 (0x00u) /* 1 enable TX part in Half Duplex mode */
#define USBUART_1_CTRL_HD_SEND_BREAK_SHIFT           (0x01u) /* 1 send BREAK signal in Half Duplez mode */
#define USBUART_1_CTRL_MARK_SHIFT                    (0x02u) /* 1 sets mark, 0 sets space */
#define USBUART_1_CTRL_PARITY_TYPE0_SHIFT            (0x03u) /* Defines the type of parity implemented */
#define USBUART_1_CTRL_PARITY_TYPE1_SHIFT            (0x04u) /* Defines the type of parity implemented */
#define USBUART_1_CTRL_RXADDR_MODE0_SHIFT            (0x05u)
#define USBUART_1_CTRL_RXADDR_MODE1_SHIFT            (0x06u)
#define USBUART_1_CTRL_RXADDR_MODE2_SHIFT            (0x07u)

#define USBUART_1_CTRL_HD_SEND               (uint8)(0x01u << USBUART_1_CTRL_HD_SEND_SHIFT)
#define USBUART_1_CTRL_HD_SEND_BREAK         (uint8)(0x01u << USBUART_1_CTRL_HD_SEND_BREAK_SHIFT)
#define USBUART_1_CTRL_MARK                  (uint8)(0x01u << USBUART_1_CTRL_MARK_SHIFT)
#define USBUART_1_CTRL_PARITY_TYPE_MASK      (uint8)(0x03u << USBUART_1_CTRL_PARITY_TYPE0_SHIFT)
#define USBUART_1_CTRL_RXADDR_MODE_MASK      (uint8)(0x07u << USBUART_1_CTRL_RXADDR_MODE0_SHIFT)

/* StatusI Register Interrupt Enable Control Bits. As defined by the Register map for the AUX Control Register */
#define USBUART_1_INT_ENABLE                         (0x10u)

/* Bit Counter (7-bit) Control Register Bit Definitions. As defined by the Register map for the AUX Control Register */
#define USBUART_1_CNTR_ENABLE                        (0x20u)

/*   Constants for SendBreak() "retMode" parameter  */
#define USBUART_1_SEND_BREAK                         (0x00u)
#define USBUART_1_WAIT_FOR_COMPLETE_REINIT           (0x01u)
#define USBUART_1_REINIT                             (0x02u)
#define USBUART_1_SEND_WAIT_REINIT                   (0x03u)

#define USBUART_1_OVER_SAMPLE_8                      (8u)
#define USBUART_1_OVER_SAMPLE_16                     (16u)

#define USBUART_1_BIT_CENTER                         (USBUART_1_OVER_SAMPLE_COUNT - 2u)

#define USBUART_1_FIFO_LENGTH                        (4u)
#define USBUART_1_NUMBER_OF_START_BIT                (1u)
#define USBUART_1_MAX_BYTE_VALUE                     (0xFFu)

/* 8X always for count7 implementation */
#define USBUART_1_TXBITCTR_BREAKBITS8X   ((USBUART_1_BREAK_BITS_TX * USBUART_1_OVER_SAMPLE_8) - 1u)
/* 8X or 16X for DP implementation */
#define USBUART_1_TXBITCTR_BREAKBITS ((USBUART_1_BREAK_BITS_TX * USBUART_1_OVER_SAMPLE_COUNT) - 1u)

#define USBUART_1_HALF_BIT_COUNT   \
                            (((USBUART_1_OVER_SAMPLE_COUNT / 2u) + (USBUART_1_USE23POLLING * 1u)) - 2u)
#if (USBUART_1_OVER_SAMPLE_COUNT == USBUART_1_OVER_SAMPLE_8)
    #define USBUART_1_HD_TXBITCTR_INIT   (((USBUART_1_BREAK_BITS_TX + \
                            USBUART_1_NUMBER_OF_START_BIT) * USBUART_1_OVER_SAMPLE_COUNT) - 1u)

    /* This parameter is increased on the 2 in 2 out of 3 mode to sample voting in the middle */
    #define USBUART_1_RXBITCTR_INIT  ((((USBUART_1_BREAK_BITS_RX + USBUART_1_NUMBER_OF_START_BIT) \
                            * USBUART_1_OVER_SAMPLE_COUNT) + USBUART_1_HALF_BIT_COUNT) - 1u)

#else /* USBUART_1_OVER_SAMPLE_COUNT == USBUART_1_OVER_SAMPLE_16 */
    #define USBUART_1_HD_TXBITCTR_INIT   ((8u * USBUART_1_OVER_SAMPLE_COUNT) - 1u)
    /* 7bit counter need one more bit for OverSampleCount = 16 */
    #define USBUART_1_RXBITCTR_INIT      (((7u * USBUART_1_OVER_SAMPLE_COUNT) - 1u) + \
                                                      USBUART_1_HALF_BIT_COUNT)
#endif /* End USBUART_1_OVER_SAMPLE_COUNT */

#define USBUART_1_HD_RXBITCTR_INIT                   USBUART_1_RXBITCTR_INIT


/***************************************
* Global variables external identifier
***************************************/

extern uint8 USBUART_1_initVar;
#if (USBUART_1_TX_INTERRUPT_ENABLED && USBUART_1_TX_ENABLED)
    extern volatile uint8 USBUART_1_txBuffer[USBUART_1_TX_BUFFER_SIZE];
    extern volatile uint8 USBUART_1_txBufferRead;
    extern uint8 USBUART_1_txBufferWrite;
#endif /* (USBUART_1_TX_INTERRUPT_ENABLED && USBUART_1_TX_ENABLED) */
#if (USBUART_1_RX_INTERRUPT_ENABLED && (USBUART_1_RX_ENABLED || USBUART_1_HD_ENABLED))
    extern uint8 USBUART_1_errorStatus;
    extern volatile uint8 USBUART_1_rxBuffer[USBUART_1_RX_BUFFER_SIZE];
    extern volatile uint8 USBUART_1_rxBufferRead;
    extern volatile uint8 USBUART_1_rxBufferWrite;
    extern volatile uint8 USBUART_1_rxBufferLoopDetect;
    extern volatile uint8 USBUART_1_rxBufferOverflow;
    #if (USBUART_1_RXHW_ADDRESS_ENABLED)
        extern volatile uint8 USBUART_1_rxAddressMode;
        extern volatile uint8 USBUART_1_rxAddressDetected;
    #endif /* (USBUART_1_RXHW_ADDRESS_ENABLED) */
#endif /* (USBUART_1_RX_INTERRUPT_ENABLED && (USBUART_1_RX_ENABLED || USBUART_1_HD_ENABLED)) */


/***************************************
* Enumerated Types and Parameters
***************************************/

#define USBUART_1__B_UART__AM_SW_BYTE_BYTE 1
#define USBUART_1__B_UART__AM_SW_DETECT_TO_BUFFER 2
#define USBUART_1__B_UART__AM_HW_BYTE_BY_BYTE 3
#define USBUART_1__B_UART__AM_HW_DETECT_TO_BUFFER 4
#define USBUART_1__B_UART__AM_NONE 0

#define USBUART_1__B_UART__NONE_REVB 0
#define USBUART_1__B_UART__EVEN_REVB 1
#define USBUART_1__B_UART__ODD_REVB 2
#define USBUART_1__B_UART__MARK_SPACE_REVB 3



/***************************************
*    Initial Parameter Constants
***************************************/

/* UART shifts max 8 bits, Mark/Space functionality working if 9 selected */
#define USBUART_1_NUMBER_OF_DATA_BITS    ((8u > 8u) ? 8u : 8u)
#define USBUART_1_NUMBER_OF_STOP_BITS    (1u)

#if (USBUART_1_RXHW_ADDRESS_ENABLED)
    #define USBUART_1_RX_ADDRESS_MODE    (0u)
    #define USBUART_1_RX_HW_ADDRESS1     (0u)
    #define USBUART_1_RX_HW_ADDRESS2     (0u)
#endif /* (USBUART_1_RXHW_ADDRESS_ENABLED) */

#define USBUART_1_INIT_RX_INTERRUPTS_MASK \
                                  (uint8)((1 << USBUART_1_RX_STS_FIFO_NOTEMPTY_SHIFT) \
                                        | (0 << USBUART_1_RX_STS_MRKSPC_SHIFT) \
                                        | (0 << USBUART_1_RX_STS_ADDR_MATCH_SHIFT) \
                                        | (0 << USBUART_1_RX_STS_PAR_ERROR_SHIFT) \
                                        | (0 << USBUART_1_RX_STS_STOP_ERROR_SHIFT) \
                                        | (0 << USBUART_1_RX_STS_BREAK_SHIFT) \
                                        | (0 << USBUART_1_RX_STS_OVERRUN_SHIFT))

#define USBUART_1_INIT_TX_INTERRUPTS_MASK \
                                  (uint8)((0 << USBUART_1_TX_STS_COMPLETE_SHIFT) \
                                        | (0 << USBUART_1_TX_STS_FIFO_EMPTY_SHIFT) \
                                        | (0 << USBUART_1_TX_STS_FIFO_FULL_SHIFT) \
                                        | (0 << USBUART_1_TX_STS_FIFO_NOT_FULL_SHIFT))


/***************************************
*              Registers
***************************************/

#ifdef USBUART_1_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG
    #define USBUART_1_CONTROL_REG \
                            (* (reg8 *) USBUART_1_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG )
    #define USBUART_1_CONTROL_PTR \
                            (  (reg8 *) USBUART_1_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG )
#endif /* End USBUART_1_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */

#if(USBUART_1_TX_ENABLED)
    #define USBUART_1_TXDATA_REG          (* (reg8 *) USBUART_1_BUART_sTX_TxShifter_u0__F0_REG)
    #define USBUART_1_TXDATA_PTR          (  (reg8 *) USBUART_1_BUART_sTX_TxShifter_u0__F0_REG)
    #define USBUART_1_TXDATA_AUX_CTL_REG  (* (reg8 *) USBUART_1_BUART_sTX_TxShifter_u0__DP_AUX_CTL_REG)
    #define USBUART_1_TXDATA_AUX_CTL_PTR  (  (reg8 *) USBUART_1_BUART_sTX_TxShifter_u0__DP_AUX_CTL_REG)
    #define USBUART_1_TXSTATUS_REG        (* (reg8 *) USBUART_1_BUART_sTX_TxSts__STATUS_REG)
    #define USBUART_1_TXSTATUS_PTR        (  (reg8 *) USBUART_1_BUART_sTX_TxSts__STATUS_REG)
    #define USBUART_1_TXSTATUS_MASK_REG   (* (reg8 *) USBUART_1_BUART_sTX_TxSts__MASK_REG)
    #define USBUART_1_TXSTATUS_MASK_PTR   (  (reg8 *) USBUART_1_BUART_sTX_TxSts__MASK_REG)
    #define USBUART_1_TXSTATUS_ACTL_REG   (* (reg8 *) USBUART_1_BUART_sTX_TxSts__STATUS_AUX_CTL_REG)
    #define USBUART_1_TXSTATUS_ACTL_PTR   (  (reg8 *) USBUART_1_BUART_sTX_TxSts__STATUS_AUX_CTL_REG)

    /* DP clock */
    #if(USBUART_1_TXCLKGEN_DP)
        #define USBUART_1_TXBITCLKGEN_CTR_REG        \
                                        (* (reg8 *) USBUART_1_BUART_sTX_sCLOCK_TxBitClkGen__D0_REG)
        #define USBUART_1_TXBITCLKGEN_CTR_PTR        \
                                        (  (reg8 *) USBUART_1_BUART_sTX_sCLOCK_TxBitClkGen__D0_REG)
        #define USBUART_1_TXBITCLKTX_COMPLETE_REG    \
                                        (* (reg8 *) USBUART_1_BUART_sTX_sCLOCK_TxBitClkGen__D1_REG)
        #define USBUART_1_TXBITCLKTX_COMPLETE_PTR    \
                                        (  (reg8 *) USBUART_1_BUART_sTX_sCLOCK_TxBitClkGen__D1_REG)
    #else     /* Count7 clock*/
        #define USBUART_1_TXBITCTR_PERIOD_REG    \
                                        (* (reg8 *) USBUART_1_BUART_sTX_sCLOCK_TxBitCounter__PERIOD_REG)
        #define USBUART_1_TXBITCTR_PERIOD_PTR    \
                                        (  (reg8 *) USBUART_1_BUART_sTX_sCLOCK_TxBitCounter__PERIOD_REG)
        #define USBUART_1_TXBITCTR_CONTROL_REG   \
                                        (* (reg8 *) USBUART_1_BUART_sTX_sCLOCK_TxBitCounter__CONTROL_AUX_CTL_REG)
        #define USBUART_1_TXBITCTR_CONTROL_PTR   \
                                        (  (reg8 *) USBUART_1_BUART_sTX_sCLOCK_TxBitCounter__CONTROL_AUX_CTL_REG)
        #define USBUART_1_TXBITCTR_COUNTER_REG   \
                                        (* (reg8 *) USBUART_1_BUART_sTX_sCLOCK_TxBitCounter__COUNT_REG)
        #define USBUART_1_TXBITCTR_COUNTER_PTR   \
                                        (  (reg8 *) USBUART_1_BUART_sTX_sCLOCK_TxBitCounter__COUNT_REG)
    #endif /* USBUART_1_TXCLKGEN_DP */

#endif /* End USBUART_1_TX_ENABLED */

#if(USBUART_1_HD_ENABLED)

    #define USBUART_1_TXDATA_REG             (* (reg8 *) USBUART_1_BUART_sRX_RxShifter_u0__F1_REG )
    #define USBUART_1_TXDATA_PTR             (  (reg8 *) USBUART_1_BUART_sRX_RxShifter_u0__F1_REG )
    #define USBUART_1_TXDATA_AUX_CTL_REG     (* (reg8 *) USBUART_1_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)
    #define USBUART_1_TXDATA_AUX_CTL_PTR     (  (reg8 *) USBUART_1_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)

    #define USBUART_1_TXSTATUS_REG           (* (reg8 *) USBUART_1_BUART_sRX_RxSts__STATUS_REG )
    #define USBUART_1_TXSTATUS_PTR           (  (reg8 *) USBUART_1_BUART_sRX_RxSts__STATUS_REG )
    #define USBUART_1_TXSTATUS_MASK_REG      (* (reg8 *) USBUART_1_BUART_sRX_RxSts__MASK_REG )
    #define USBUART_1_TXSTATUS_MASK_PTR      (  (reg8 *) USBUART_1_BUART_sRX_RxSts__MASK_REG )
    #define USBUART_1_TXSTATUS_ACTL_REG      (* (reg8 *) USBUART_1_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
    #define USBUART_1_TXSTATUS_ACTL_PTR      (  (reg8 *) USBUART_1_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
#endif /* End USBUART_1_HD_ENABLED */

#if( (USBUART_1_RX_ENABLED) || (USBUART_1_HD_ENABLED) )
    #define USBUART_1_RXDATA_REG             (* (reg8 *) USBUART_1_BUART_sRX_RxShifter_u0__F0_REG )
    #define USBUART_1_RXDATA_PTR             (  (reg8 *) USBUART_1_BUART_sRX_RxShifter_u0__F0_REG )
    #define USBUART_1_RXADDRESS1_REG         (* (reg8 *) USBUART_1_BUART_sRX_RxShifter_u0__D0_REG )
    #define USBUART_1_RXADDRESS1_PTR         (  (reg8 *) USBUART_1_BUART_sRX_RxShifter_u0__D0_REG )
    #define USBUART_1_RXADDRESS2_REG         (* (reg8 *) USBUART_1_BUART_sRX_RxShifter_u0__D1_REG )
    #define USBUART_1_RXADDRESS2_PTR         (  (reg8 *) USBUART_1_BUART_sRX_RxShifter_u0__D1_REG )
    #define USBUART_1_RXDATA_AUX_CTL_REG     (* (reg8 *) USBUART_1_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)

    #define USBUART_1_RXBITCTR_PERIOD_REG    (* (reg8 *) USBUART_1_BUART_sRX_RxBitCounter__PERIOD_REG )
    #define USBUART_1_RXBITCTR_PERIOD_PTR    (  (reg8 *) USBUART_1_BUART_sRX_RxBitCounter__PERIOD_REG )
    #define USBUART_1_RXBITCTR_CONTROL_REG   \
                                        (* (reg8 *) USBUART_1_BUART_sRX_RxBitCounter__CONTROL_AUX_CTL_REG )
    #define USBUART_1_RXBITCTR_CONTROL_PTR   \
                                        (  (reg8 *) USBUART_1_BUART_sRX_RxBitCounter__CONTROL_AUX_CTL_REG )
    #define USBUART_1_RXBITCTR_COUNTER_REG   (* (reg8 *) USBUART_1_BUART_sRX_RxBitCounter__COUNT_REG )
    #define USBUART_1_RXBITCTR_COUNTER_PTR   (  (reg8 *) USBUART_1_BUART_sRX_RxBitCounter__COUNT_REG )

    #define USBUART_1_RXSTATUS_REG           (* (reg8 *) USBUART_1_BUART_sRX_RxSts__STATUS_REG )
    #define USBUART_1_RXSTATUS_PTR           (  (reg8 *) USBUART_1_BUART_sRX_RxSts__STATUS_REG )
    #define USBUART_1_RXSTATUS_MASK_REG      (* (reg8 *) USBUART_1_BUART_sRX_RxSts__MASK_REG )
    #define USBUART_1_RXSTATUS_MASK_PTR      (  (reg8 *) USBUART_1_BUART_sRX_RxSts__MASK_REG )
    #define USBUART_1_RXSTATUS_ACTL_REG      (* (reg8 *) USBUART_1_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
    #define USBUART_1_RXSTATUS_ACTL_PTR      (  (reg8 *) USBUART_1_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
#endif /* End  (USBUART_1_RX_ENABLED) || (USBUART_1_HD_ENABLED) */

#if(USBUART_1_INTERNAL_CLOCK_USED)
    /* Register to enable or disable the digital clocks */
    #define USBUART_1_INTCLOCK_CLKEN_REG     (* (reg8 *) USBUART_1_IntClock__PM_ACT_CFG)
    #define USBUART_1_INTCLOCK_CLKEN_PTR     (  (reg8 *) USBUART_1_IntClock__PM_ACT_CFG)

    /* Clock mask for this clock. */
    #define USBUART_1_INTCLOCK_CLKEN_MASK    USBUART_1_IntClock__PM_ACT_MSK
#endif /* End USBUART_1_INTERNAL_CLOCK_USED */


/***************************************
*       Register Constants
***************************************/

#if(USBUART_1_TX_ENABLED)
    #define USBUART_1_TX_FIFO_CLR            (0x01u) /* FIFO0 CLR */
#endif /* End USBUART_1_TX_ENABLED */

#if(USBUART_1_HD_ENABLED)
    #define USBUART_1_TX_FIFO_CLR            (0x02u) /* FIFO1 CLR */
#endif /* End USBUART_1_HD_ENABLED */

#if( (USBUART_1_RX_ENABLED) || (USBUART_1_HD_ENABLED) )
    #define USBUART_1_RX_FIFO_CLR            (0x01u) /* FIFO0 CLR */
#endif /* End  (USBUART_1_RX_ENABLED) || (USBUART_1_HD_ENABLED) */


/***************************************
* The following code is DEPRECATED and
* should not be used in new projects.
***************************************/

/* UART v2_40 obsolete definitions */
#define USBUART_1_WAIT_1_MS      USBUART_1_BL_CHK_DELAY_MS   

#define USBUART_1_TXBUFFERSIZE   USBUART_1_TX_BUFFER_SIZE
#define USBUART_1_RXBUFFERSIZE   USBUART_1_RX_BUFFER_SIZE

#if (USBUART_1_RXHW_ADDRESS_ENABLED)
    #define USBUART_1_RXADDRESSMODE  USBUART_1_RX_ADDRESS_MODE
    #define USBUART_1_RXHWADDRESS1   USBUART_1_RX_HW_ADDRESS1
    #define USBUART_1_RXHWADDRESS2   USBUART_1_RX_HW_ADDRESS2
    /* Backward compatible define */
    #define USBUART_1_RXAddressMode  USBUART_1_RXADDRESSMODE
#endif /* (USBUART_1_RXHW_ADDRESS_ENABLED) */

/* UART v2_30 obsolete definitions */
#define USBUART_1_initvar                    USBUART_1_initVar

#define USBUART_1_RX_Enabled                 USBUART_1_RX_ENABLED
#define USBUART_1_TX_Enabled                 USBUART_1_TX_ENABLED
#define USBUART_1_HD_Enabled                 USBUART_1_HD_ENABLED
#define USBUART_1_RX_IntInterruptEnabled     USBUART_1_RX_INTERRUPT_ENABLED
#define USBUART_1_TX_IntInterruptEnabled     USBUART_1_TX_INTERRUPT_ENABLED
#define USBUART_1_InternalClockUsed          USBUART_1_INTERNAL_CLOCK_USED
#define USBUART_1_RXHW_Address_Enabled       USBUART_1_RXHW_ADDRESS_ENABLED
#define USBUART_1_OverSampleCount            USBUART_1_OVER_SAMPLE_COUNT
#define USBUART_1_ParityType                 USBUART_1_PARITY_TYPE

#if( USBUART_1_TX_ENABLED && (USBUART_1_TXBUFFERSIZE > USBUART_1_FIFO_LENGTH))
    #define USBUART_1_TXBUFFER               USBUART_1_txBuffer
    #define USBUART_1_TXBUFFERREAD           USBUART_1_txBufferRead
    #define USBUART_1_TXBUFFERWRITE          USBUART_1_txBufferWrite
#endif /* End USBUART_1_TX_ENABLED */
#if( ( USBUART_1_RX_ENABLED || USBUART_1_HD_ENABLED ) && \
     (USBUART_1_RXBUFFERSIZE > USBUART_1_FIFO_LENGTH) )
    #define USBUART_1_RXBUFFER               USBUART_1_rxBuffer
    #define USBUART_1_RXBUFFERREAD           USBUART_1_rxBufferRead
    #define USBUART_1_RXBUFFERWRITE          USBUART_1_rxBufferWrite
    #define USBUART_1_RXBUFFERLOOPDETECT     USBUART_1_rxBufferLoopDetect
    #define USBUART_1_RXBUFFER_OVERFLOW      USBUART_1_rxBufferOverflow
#endif /* End USBUART_1_RX_ENABLED */

#ifdef USBUART_1_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG
    #define USBUART_1_CONTROL                USBUART_1_CONTROL_REG
#endif /* End USBUART_1_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */

#if(USBUART_1_TX_ENABLED)
    #define USBUART_1_TXDATA                 USBUART_1_TXDATA_REG
    #define USBUART_1_TXSTATUS               USBUART_1_TXSTATUS_REG
    #define USBUART_1_TXSTATUS_MASK          USBUART_1_TXSTATUS_MASK_REG
    #define USBUART_1_TXSTATUS_ACTL          USBUART_1_TXSTATUS_ACTL_REG
    /* DP clock */
    #if(USBUART_1_TXCLKGEN_DP)
        #define USBUART_1_TXBITCLKGEN_CTR        USBUART_1_TXBITCLKGEN_CTR_REG
        #define USBUART_1_TXBITCLKTX_COMPLETE    USBUART_1_TXBITCLKTX_COMPLETE_REG
    #else     /* Count7 clock*/
        #define USBUART_1_TXBITCTR_PERIOD        USBUART_1_TXBITCTR_PERIOD_REG
        #define USBUART_1_TXBITCTR_CONTROL       USBUART_1_TXBITCTR_CONTROL_REG
        #define USBUART_1_TXBITCTR_COUNTER       USBUART_1_TXBITCTR_COUNTER_REG
    #endif /* USBUART_1_TXCLKGEN_DP */
#endif /* End USBUART_1_TX_ENABLED */

#if(USBUART_1_HD_ENABLED)
    #define USBUART_1_TXDATA                 USBUART_1_TXDATA_REG
    #define USBUART_1_TXSTATUS               USBUART_1_TXSTATUS_REG
    #define USBUART_1_TXSTATUS_MASK          USBUART_1_TXSTATUS_MASK_REG
    #define USBUART_1_TXSTATUS_ACTL          USBUART_1_TXSTATUS_ACTL_REG
#endif /* End USBUART_1_HD_ENABLED */

#if( (USBUART_1_RX_ENABLED) || (USBUART_1_HD_ENABLED) )
    #define USBUART_1_RXDATA                 USBUART_1_RXDATA_REG
    #define USBUART_1_RXADDRESS1             USBUART_1_RXADDRESS1_REG
    #define USBUART_1_RXADDRESS2             USBUART_1_RXADDRESS2_REG
    #define USBUART_1_RXBITCTR_PERIOD        USBUART_1_RXBITCTR_PERIOD_REG
    #define USBUART_1_RXBITCTR_CONTROL       USBUART_1_RXBITCTR_CONTROL_REG
    #define USBUART_1_RXBITCTR_COUNTER       USBUART_1_RXBITCTR_COUNTER_REG
    #define USBUART_1_RXSTATUS               USBUART_1_RXSTATUS_REG
    #define USBUART_1_RXSTATUS_MASK          USBUART_1_RXSTATUS_MASK_REG
    #define USBUART_1_RXSTATUS_ACTL          USBUART_1_RXSTATUS_ACTL_REG
#endif /* End  (USBUART_1_RX_ENABLED) || (USBUART_1_HD_ENABLED) */

#if(USBUART_1_INTERNAL_CLOCK_USED)
    #define USBUART_1_INTCLOCK_CLKEN         USBUART_1_INTCLOCK_CLKEN_REG
#endif /* End USBUART_1_INTERNAL_CLOCK_USED */

#define USBUART_1_WAIT_FOR_COMLETE_REINIT    USBUART_1_WAIT_FOR_COMPLETE_REINIT

#endif  /* CY_UART_USBUART_1_H */


/* [] END OF FILE */
